### Hexlet tests and linter status:
[![Actions Status](https://github.com/Levon-Kharajyan/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Levon-Kharajyan/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3b550e7aa06b6bc01129/maintainability)](https://codeclimate.com/github/Levon-Kharajyan/python-project-49/maintainability)
